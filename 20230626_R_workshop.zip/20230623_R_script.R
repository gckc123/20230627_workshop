install.packages("tidyverse")

library("tidyverse")

#setting working directory
setwd("C:\\Users\\gckc1\\Google Drive\\Post doc\\Presentations\\2023 Griffith R workshop")

#reading data
data <- read.csv("Kathy data.csv")

#data summary
summary(data)

#using the $ sign to access a column
data$w1Gender

data$w1gender

#example for selecting a subset of variable
data.1 <- data %>%
  select(w1age, w1Gender, w1LifeSat, w1DASS21_STRESS, w1FQS, w1Audit)

summary(data.1)

#checking the age column
data_missing_age <- data %>%
  filter(is.na(w1age))

data_missing_age

data_missing_error_age <- data %>%
  filter(is.na(w1age) | w1age < 10)

data_missing_error_age

#checking the age and 
data_missing_error_age_missing_lifesat <- data %>%
  filter(is.na(w1age) | w1age < 10 | is.na(w1LifeSat))

data_missing_error_age_missing_lifesat

#cleaning age data - re-coding w1age to NA if w1age is less than 10.
data <- data %>%
  mutate(w1age_new = case_when(
    w1age < 10 ~ NA,
    w1age > 10 ~ w1age
  ))

#creating age group
data <- data %>%
  mutate(w1age_cat = case_when(
    w1age < 10 ~ NA,
    w1age >= 10 & w1age < 20 ~ 0,
    w1age >= 20 & w1age < 25 ~ 1,
    w1age >= 25 ~ 2
    
  ))

#basic descriptive
mean(data$w1age_new)
mean(data$w1age_new, na.rm = TRUE)

sd(data$w1age_new, na.rm = TRUE)
median(data$w1age_new, na.rm = TRUE)
IQR(data$w1age_new, na.rm = TRUE)

#simple table
table(data$w1Gender)
table(data$w1age_cat)

table(data$w1Gender, useNA = "ifany")
table(data$w1age_cat, useNA = "ifany")

prop.table(table(data$w1Gender, useNA = "ifany"))
prop.table(table(data$w1age_cat, useNA = "ifany"))

#crosstab
xtabs(~ w1Gender + w1age_cat, data = data, addNA = TRUE)
prop.table(xtabs(~ w1Gender + w1age_cat, data = data, addNA = TRUE))

xtabs(~ w1Gender + w1age_cat, data = data)
prop.table(xtabs(~ w1Gender + w1age_cat, data = data))

prop.table(xtabs(~ w1Gender + w1age_cat, data = data), margin = 1)
prop.table(xtabs(~ w1Gender + w1age_cat, data = data), margin = 2)

#tidyverse descriptive 
data %>%
  summarize(mean_age = mean(w1age_new, na.rm = TRUE),
            sd_age = sd(w1age_new, na.rm = TRUE),
            mean_lifesat = mean(w1LifeSat, na.rm = TRUE),
            sd_lifesat = sd(w1LifeSat, na.rm = TRUE))

data %>%
  group_by(w1age_cat, w1Gender) %>%
  summarize(mean_age = mean(w1age_new, na.rm = TRUE),
            sd_age = sd(w1age_new, na.rm = TRUE),
            mean_lifesat = mean(w1LifeSat, na.rm = TRUE),
            sd_lifesat = sd(w1LifeSat, na.rm = TRUE))

data$dass_total <- data$w1DASS21_ANXIETY + data$w1DASS21_DEPRESSION + data$w1DASS21_STRESS

data %>%
  ggplot(aes(x = w1LifeSat, y = w1DASS21_DEPRESSION))+
  geom_point()

data %>%
  ggplot(aes(x = w1LifeSat, y = w1DASS21_DEPRESSION))+
  geom_jitter()

data %>%
  ggplot(aes(x = w1LifeSat, y = w1DASS21_DEPRESSION))+
  geom_jitter()+
  geom_smooth()

data %>%
  ggplot(aes(x = w1LifeSat, y = w1DASS21_DEPRESSION))+
  geom_jitter()+
  geom_smooth(method = "lm", se = TRUE, level = 0.95)

data %>%
  ggplot(aes(x = w1LifeSat, y = w1DASS21_DEPRESSION))+
  geom_jitter()+
  geom_smooth(method = "lm", se = TRUE, level = 0.95)+
  facet_wrap(~ w1age_cat)

data %>%
  ggplot(aes(x = w1LifeSat, y = w1DASS21_DEPRESSION))+
  geom_jitter()+
  geom_smooth(method = "lm", se = TRUE, level = 0.95)+
  facet_wrap(~ w1age_cat + w1Gender)

data %>%
  ggplot(aes(x = w1LifeSat, y = w1DASS21_DEPRESSION))+
  geom_jitter()+
  geom_smooth(method = "lm", se = TRUE, level = 0.95)+
  facet_grid(w1age_cat ~ w1Gender)

data$w1Gender <- factor(data$w1Gender, levels = c("0","1","2"),
                         labels = c("Male", "Female", "Other"))

data$w1age_cat <- factor(data$w1age_cat, levels = c("0","1","2"),
                         labels = c("Between 10 and 19","Between 20 and 24", "Over 25"))

data %>%
  ggplot(aes(x = w1LifeSat, y = w1DASS21_DEPRESSION))+
  geom_jitter()+
  geom_smooth(method = "lm", se = TRUE, level = 0.95)+
  facet_grid(w1age_cat ~ w1Gender)
 
data %>%
  drop_na(w1age_cat) %>%
  ggplot(aes(x = w1LifeSat, y = w1DASS21_DEPRESSION))+
  geom_jitter()+
  geom_smooth(method = "lm", se = TRUE, level = 0.95)+
  facet_grid(w1age_cat ~ w1Gender)

data %>%
  drop_na(w1age_cat) %>%
  ggplot(aes(x = w1LifeSat, y = w1DASS21_DEPRESSION))+
  geom_jitter()+
  geom_smooth(method = "lm", se = TRUE, level = 0.95)+
  facet_grid(w1age_cat ~ w1Gender) +
  ylim(-0.5,20) +
  ggtitle("Scatterplot of Life satisfaction and Depression") +
  xlab("Life Satisfaction") +
  ylab("DASS Depression score") +
  theme_bw()
  
data %>%
  drop_na(w1age_cat) %>%
  ggplot(aes(x = w1LifeSat, y = w1DASS21_DEPRESSION, color = w1Gender))+
  geom_jitter()+
  geom_smooth(method = "lm", se = TRUE, level = 0.95)+
  facet_wrap(~ w1age_cat) +
  ylim(-0.5,20) +
  ggtitle("Scatterplot of Life satisfaction and Depression") +
  xlab("Life Satisfaction") +
  ylab("DASS Depression score") +
  labs(color = "Gender") +
  theme_bw()

data %>%
  ggplot(aes(x = w1LifeSat)) +
  geom_histogram(color = "white")

data %>%
  ggplot(aes(x = w1LifeSat, fill = w1Gender)) +
  geom_histogram(color = "white")

data %>%
  ggplot(aes(x = w1LifeSat, fill = w1Gender)) +
  geom_histogram(color = "white", alpha = 0.6) +
  facet_wrap(~ w1age_cat)

data %>%
  ggplot(aes(x = w1LifeSat, fill = w1Gender, color = w1Gender)) +
  geom_density(alpha = 0.2) +
  facet_wrap(~ w1age_cat)

data %>%
  ggplot(aes(y = w1LifeSat)) +
  geom_boxplot()

data %>%
  ggplot(aes(y = w1LifeSat, x = w1age_cat, fill = w1Gender)) +
  geom_boxplot()

data %>%
  ggplot(aes(y = w1LifeSat, x = w1age_cat, fill = w1Gender)) +
  geom_violin()

#keep only males and females 
data_MF <- data %>%
  filter(w1Gender == "Male" | w1Gender == "Female")

table(data_MF$w1Gender, useNA = "ifany")

#install the emmeans package
install.packages("emmeans")
install.packages("car")

library(emmeans)
library(car)

#linear model

################################################################################

res.1 <- lm(w1LifeSat ~ w1Gender, data = data_MF)
summary(res.1)

confint(res.1, level = 0.95)

t.test(w1LifeSat ~ w1Gender, data = data_MF, var.equal= TRUE)

################################################################################

res.2 <- lm(w1LifeSat ~ w1age_cat, data = data_MF)
summary(res.2)
confint(res.2, level = 0.95)

aov.1 <- aov(w1LifeSat ~ w1age_cat, data = data_MF)
summary(aov.1)

emm_res.2 <- emmeans(res.2, pairwise ~ w1age_cat, level = 0.95)
summary(emm_res.2)

################################################################################

res.3 <- lm(w1LifeSat ~ w1age_cat + w1Gender + w1DASS21_STRESS + w1FQS + w1Audit, data = data_MF)
summary(res.3)
confint(res.3, level = 0.95)

res.3.std <- data.frame("residuals" = rstandard(res.3))
res.3.std %>%
  ggplot(aes(x = residuals)) +
  geom_histogram(color = "white")

res.3.std %>%  
  ggplot(aes(sample = residuals)) +
  geom_qq() +
  geom_qq_line()

outlierTest(res.3)
infIndexPlot(res.3)
residualPlots(res.3)

################################################################################

res.4 <- lm(w1LifeSat ~ w1age_cat + w1Gender * w1DASS21_STRESS + w1FQS + w1Audit, data = data_MF)
summary(res.4)
confint(res.4, level = 0.95)

m_w1DASS21_STRESS<- mean(data_MF$w1DASS21_STRESS, na.rm = TRUE)
sd_w1DASS21_STRESS<- sd(data_MF$w1DASS21_STRESS, na.rm = TRUE)

emm <- emmeans(res.4, pairwise ~ w1DASS21_STRESS*w1Gender,
               cov.keep = 3, 
               at = list(w1DASS21_STRESS = c(m_w1DASS21_STRESS-sd_w1DASS21_STRESS, 
                                             m_w1DASS21_STRESS, 
                                             m_w1DASS21_STRESS+sd_w1DASS21_STRESS)), level = 0.95)
summary(emm)

res.4.mod <- emtrends(res.4, pairwise ~ w1Gender, var = "w1DASS21_STRESS", level= 0.95)
summary(res.4.mod)

emmip(res.4, w1Gender ~ w1DASS21_STRESS,
      cov.keep = 3, at = list(
        w1DASS21_STRESS = c(m_w1DASS21_STRESS-sd_w1DASS21_STRESS,
                            m_w1DASS21_STRESS, 
                            m_w1DASS21_STRESS+sd_w1DASS21_STRESS)),
      CIs = TRUE, level = 0.95, position = "jitter")

################################################################################

res.5 <- lm(w1LifeSat ~ w1age_cat + w1Gender + w1DASS21_STRESS * w1FQS + w1Audit, data = data_MF)
summary(res.5)
confint(res.5, level = 0.95)


m_w1DASS21_STRESS<- mean(data_MF$w1DASS21_STRESS, na.rm = TRUE)
sd_w1DASS21_STRESS<- sd(data_MF$w1DASS21_STRESS, na.rm = TRUE)

m_w1FQS<- mean(data_MF$w1FQS, na.rm = TRUE)
sd_w1FQS<- sd(data_MF$w1FQS, na.rm = TRUE)


emm <- emmeans(res.5, pairwise ~ w1DASS21_STRESS*w1FQS,
               cov.keep = 3, at = list(
                 w1DASS21_STRESS = c(m_w1DASS21_STRESS-sd_w1DASS21_STRESS, 
                                     m_w1DASS21_STRESS, 
                                     m_w1DASS21_STRESS+sd_w1DASS21_STRESS),
                 w1FQS = c(m_w1FQS-sd_w1FQS, 
                           m_w1FQS, 
                           m_w1FQS+sd_w1FQS)), level = 0.95)
summary(emm)

res.5.mod <- emtrends(res.5, pairwise ~ w1FQS, var = "w1DASS21_STRESS",
                        cov.keep = 3, at = list(
                          w1FQS = c(m_w1FQS-sd_w1FQS, m_w1FQS, m_w1FQS+sd_w1FQS)), level = 0.95)
summary(res.5.mod)

emmip(res.5, w1FQS ~ w1DASS21_STRESS,
      cov.keep = 3, at = list(
        w1DASS21_STRESS = c(m_w1DASS21_STRESS-sd_w1DASS21_STRESS, 
                            m_w1DASS21_STRESS, 
                            m_w1DASS21_STRESS+sd_w1DASS21_STRESS),
        w1FQS = c(m_w1FQS-sd_w1FQS, 
                  m_w1FQS, 
                  m_w1FQS+sd_w1FQS)),
      CIs = TRUE, level = 0.95, position = "jitter")

################################################################################

data_MF <- data_MF %>%
  mutate(w1Audit_cat = case_when(
    w1Audit < 8 ~ 0,
    w1Audit >= 8 ~ 1,
    w1Audit == NA ~ NA,
  ))

res.6 <- glm(w1Audit_cat ~ w1Gender + w1age_cat + w1DERS + w1DASS21_STRESS, family = binomial, data = data_MF)
summary(res.6)

cbind(coef(res.6), confint(res.6, level = 0.95))

exp(cbind(coef(res.6), confint(res.6, level = 0.95)))

################################################################################

install.packages("mice")
library(mice)

data_reduced <- data_MF %>%
  select(w1LifeSat, w1age_new, w1Gender, w1DASS21_STRESS, w1FQS, w1Audit)

imp_data <- mice(data_reduced, m = 30)

completed_data.1 <- complete(imp_data, action = 1, include = FALSE)

res.7 <- with(imp_data, lm(w1LifeSat ~ w1age_new + w1Gender + w1DASS21_STRESS + w1FQS + w1Audit))
summary(pool(res.7), conf.int = TRUE, conf.level = 0.95)

res.8 <- lm(w1LifeSat ~ w1age_new + w1Gender + w1DASS21_STRESS + w1FQS + w1Audit, data = data_MF)
summary(res.8)